"use client";

const pct=(v:number|null|undefined)=>v==null?"—":`${v>=0?"+":""}${v.toFixed(2)}%`;
const EXPANDED=new Set(["ITA","PAVE","KRE","XBI","IYT","URA","COPX","XME"]);
export default function SectorPerformance({sectors}:{sectors:any[]}){
 const rows=[...(sectors||[])].sort((a,b)=>(b.seven_day_percent??-999)-(a.seven_day_percent??-999));
 const max=Math.max(1,...rows.map(r=>Math.abs(r.seven_day_percent||0)));
 return <div className="card sector-performance-card reveal-card"><div className="section-head"><div><span className="eyebrow">Relative strength · {rows.length} tracked groups</span><h2>Sector Performance</h2></div><span className="muted small-note">7D ranking</span></div><div className="sector-bars">{rows.map((r:any)=><div className={`sector-bar-row ${EXPANDED.has(r.symbol)?"expanded-macro-etf":""}`} key={r.symbol}><div className="sector-label"><strong>{r.name}</strong><span>{r.symbol}{EXPANDED.has(r.symbol)?" · added macro ETF":""}</span></div><div className="sector-track"><div className={`sector-fill ${(r.seven_day_percent||0)>=0?"up":"down"}`} style={{width:`${Math.max(3,Math.abs(r.seven_day_percent||0)/max*100)}%`}}/></div><strong className={(r.seven_day_percent||0)>=0?"positive":"negative"}>{pct(r.seven_day_percent)}</strong></div>)}</div></div>;
}
